import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const TodoApp());
}

class TodoApp extends StatelessWidget {
  const TodoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "Professional To-Do",
      theme: ThemeData(
        primarySwatch: Colors.blue,
        textTheme: GoogleFonts.poppinsTextTheme()
            .apply(bodyColor: Colors.white, displayColor: Colors.white)
            .copyWith(
              bodyLarge:
                  const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
              bodyMedium:
                  const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              bodySmall:
                  const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            ),
      ),
      home: const TodoHome(),
    );
  }
}

class TodoHome extends StatefulWidget {
  const TodoHome({super.key});

  @override
  State<TodoHome> createState() => _TodoHomeState();
}

class _TodoHomeState extends State<TodoHome>
    with SingleTickerProviderStateMixin {
  List<Map<String, dynamic>> tasks = [];
  TextEditingController controller = TextEditingController();

  late AnimationController animController;
  late Animation<double> fadeAnimation;

  @override
  void initState() {
    super.initState();
    loadTasks();

    animController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800));
    fadeAnimation = Tween<double>(begin: 0, end: 1).animate(animController);
    animController.forward();
  }

  // ---------------- LOAD TASKS ----------------
  Future<void> loadTasks() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? saved = prefs.getString("tasks");
    if (saved != null) {
      setState(() {
        tasks = List<Map<String, dynamic>>.from(json.decode(saved));
      });
    }
  }

  // ---------------- SAVE TASKS ----------------
  Future<void> saveTasks() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString("tasks", json.encode(tasks));
  }

  // ---------------- ADD TASK ----------------
  void addTask() {
    if (controller.text.trim().isEmpty) return;

    setState(() {
      tasks.add({"title": controller.text.trim(), "done": false});
    });

    controller.clear();
    saveTasks();
  }

  // ---------------- EDIT TASK ----------------
  void editTask(int index) {
    controller.text = tasks[index]["title"];
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Edit Task ✏️"),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(hintText: "Enter task"),
        ),
        actions: [
          TextButton(
            onPressed: () {
              setState(() {
                tasks[index]["title"] = controller.text.trim();
              });
              controller.clear();
              saveTasks();
              Navigator.pop(context);
            },
            child: const Text("Save"),
          )
        ],
      ),
    );
  }

  // ---------------- DELETE TASK ----------------
  void deleteTask(int index) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Delete Task ❌"),
        content:
            Text("Are you sure you want to delete '${tasks[index]['title']}'?"),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancel")),
          TextButton(
              onPressed: () {
                setState(() {
                  tasks.removeAt(index);
                });
                saveTasks();
                Navigator.pop(context);
              },
              child: const Text("Delete", style: TextStyle(color: Colors.red))),
        ],
      ),
    );
  }

  // ---------------- UI ----------------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("📅 To-Do List"),
        centerTitle: true,
        elevation: 8,
        backgroundColor: Colors.blue.shade900,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blue.shade900, Colors.blue.shade700],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        padding: const EdgeInsets.all(16),
        child: FadeTransition(
          opacity: fadeAnimation,
          child: Column(
            children: [
              // ---------- INPUT BOX ----------
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(25),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: controller,
                        style: const TextStyle(
                            color: Colors.white, fontWeight: FontWeight.bold),
                        decoration: const InputDecoration(
                          hintText: "Enter task ✏️",
                          hintStyle: TextStyle(color: Colors.white70),
                          border: InputBorder.none,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: addTask,
                      child: const CircleAvatar(
                        backgroundColor: Colors.white,
                        child: Icon(Icons.add, color: Colors.blue),
                      ),
                    )
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // ---------- TASK LIST WITH PERFECT SCROLL ----------
              Expanded(
                child: Scrollbar(
                  thumbVisibility: true,
                  child: ListView.builder(
                    padding: const EdgeInsets.only(bottom: 40),
                    itemCount: tasks.length,
                    itemBuilder: (context, index) {
                      return Card(
                        color: Colors.white,
                        margin: const EdgeInsets.symmetric(vertical: 6),
                        child: ListTile(
                          leading: Checkbox(
                            value: tasks[index]["done"],
                            onChanged: (value) {
                              setState(() {
                                tasks[index]["done"] = value!;
                              });
                              saveTasks();
                            },
                          ),

                          // TASK TEXT
                          title: Text(
                            tasks[index]["title"],
                            style: TextStyle(
                              decoration: tasks[index]["done"]
                                  ? TextDecoration.lineThrough
                                  : TextDecoration.none,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),

                          // ACTION BUTTONS
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.edit,
                                    color: Colors.orange),
                                onPressed: () => editTask(index),
                              ),
                              IconButton(
                                icon:
                                    const Icon(Icons.delete, color: Colors.red),
                                onPressed: () => deleteTask(index),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
